"""Per-camera GStreamer RTSP push (MediaMTX ingest) — Orin software x264."""

import time

import cv2

from . import config


def build_stream_writer_pipeline(width, height, fps, bitrate_kbps, ingest_url):
    key_int = max(int(fps) * 2, 10)
    return (
        "appsrc is-live=true format=time do-timestamp=true "
        "caps=video/x-raw,format=BGR,width=%d,height=%d,framerate=%d/1 ! "
        "videoconvert ! video/x-raw,format=I420 ! "
        "x264enc tune=zerolatency speed-preset=ultrafast bitrate=%d "
        "key-int-max=%d ! "
        "h264parse ! "
        "rtspclientsink location=%s protocols=tcp tls-validation-flags=0"
        % (width, height, fps, bitrate_kbps, key_int, ingest_url)
    )


class StreamWriter(object):
    def __init__(self, ingest_url, label):
        self.ingest_url = ingest_url.strip()
        self.label = label
        self.writer = None
        self.out_w = config.STREAM_WIDTH if config.STREAM_WIDTH > 0 else 0
        self.out_h = config.STREAM_HEIGHT if config.STREAM_HEIGHT > 0 else 0
        self.interval = 1.0 / config.STREAM_FPS
        self.last_write_ts = 0.0
        self._open_failed = False
        self._frames_written = 0

    def _open(self, frame_w, frame_h):
        if not self.ingest_url or self.writer is not None or self._open_failed:
            return
        out_w = self.out_w or frame_w
        out_h = self.out_h or frame_h
        print(
            "%s: opening RTSP push %dx%d @ %d fps -> .../%s"
            % (self.label, out_w, out_h, config.STREAM_FPS, self.ingest_url.rsplit("/", 1)[-1])
        )
        pipeline = build_stream_writer_pipeline(
            out_w, out_h, config.STREAM_FPS, config.STREAM_BITRATE_KBPS, self.ingest_url,
        )
        self.writer = cv2.VideoWriter(
            pipeline, cv2.CAP_GSTREAMER, 0, float(config.STREAM_FPS), (out_w, out_h), True,
        )
        if not self.writer.isOpened():
            self.writer = None
            self._open_failed = True
            print("WARNING %s: RTSP writer failed to open" % self.label)
            return
        print("%s: RTSP push active" % self.label)

    def write_paced(self, bgr):
        if not self.ingest_url:
            return
        h, w = bgr.shape[:2]
        self._open(w, h)
        if self.writer is None or not self.writer.isOpened():
            return
        now = time.time()
        if now - self.last_write_ts < self.interval:
            return
        out_w = self.out_w or w
        out_h = self.out_h or h
        out = cv2.resize(bgr, (out_w, out_h)) if (w, h) != (out_w, out_h) else bgr
        self.writer.write(out)
        self.last_write_ts = now
        self._frames_written += 1

    def frames_written(self):
        return self._frames_written

    def release(self):
        if self.writer is not None:
            self.writer.release()
            self.writer = None
